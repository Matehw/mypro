import nltk
import numpy as np
# nltk.download('punkt') # pretrained tokenizer
from nltk.stem.porter import PorterStemmer  # you can try other if you like

# stemmer.stem(word.lower())