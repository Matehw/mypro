# -*- coding:utf-8 -*-
from flask import Flask, render_template, request, jsonify
from chat import get_response


app = Flask(__name__)
'''
@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"
'''

@app.get("/")
def index_get():
    return render_template("base.html")

file_handle = open('history.txt', mode='w')
#all_list = ['']'
@app.post("/predict")
def predict():
    text = request.get_json().get("message")
    print(text)

    file_handle.write(text + "\n")
    # file_handle.close()
    # TODO : check if text is valid
    response = get_response(text)
    message = {"answer": response}
    return jsonify(message)

if __name__ == "__main__":
    app.run(use_reloader=False,host='0.0.0.0',port=80,debug=Flask)

'''
if __name__ == '__main__':

    from gevent import pywsgi

    server = pywsgi.WSGIServer(('0.0.0.0',5000),app)
    server.serve_forever()

'''
